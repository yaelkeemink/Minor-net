﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.Dag18.MonumentenData.Test
{
    [TestClass]
    public class DALTest
    {
        //[TestMethod]
        //public void MyTestMethod()
        //{

        //}
    }
}
