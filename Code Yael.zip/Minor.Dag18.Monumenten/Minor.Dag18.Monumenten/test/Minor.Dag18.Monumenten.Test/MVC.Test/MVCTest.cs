﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Minor.Dag18.Monumenten.Test
{
    [TestClass]
    public class MVCTest
    {
        [TestMethod]
        public void MyTestMethod()
        {

        }
    }
}
