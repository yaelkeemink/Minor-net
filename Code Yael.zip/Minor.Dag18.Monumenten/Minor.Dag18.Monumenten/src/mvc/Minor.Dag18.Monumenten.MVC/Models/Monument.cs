﻿namespace Minor.Dag18.Monumenten.MVC.Models
{
    public class Monument
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Location { get; set; }
    }
}