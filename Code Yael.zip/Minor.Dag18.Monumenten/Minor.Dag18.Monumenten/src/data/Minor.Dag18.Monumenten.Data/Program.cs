﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.Dag18.Monumenten.Data
{
    public class Program
    {
        public static void Main(string[] Args)
        {

        }
    }
}
