﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.Dag19.Monumenten.Data.Entities.Entities
{
    public class Entity
    {
        public int Id { get; set; } 
        public string Name { get; set; }
    }
}