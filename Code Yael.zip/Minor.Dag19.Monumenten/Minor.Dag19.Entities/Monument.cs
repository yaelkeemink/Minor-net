﻿namespace Minor.Dag19.Monumenten.Data.Entities.Entities
{
    public class Monument
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public string Location { get; set; }
    }
}