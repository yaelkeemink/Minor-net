﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.Dag14.EntityFramework.Test
{
    public class Program
    {
        
    }
}
