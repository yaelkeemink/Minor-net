﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.Dag16.InMemoryTesting.Entities
{
    public class Pen
    {
        public string Color { get; set; }

        public string Type { get; set; }

        public int Id { get; set; }
    }
}
