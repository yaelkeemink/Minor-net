﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.Dag16.InMemoryTesting.Test
{
    public class Program
    {
        public static void Main(string[] Args)
        {

        }
    }
}
