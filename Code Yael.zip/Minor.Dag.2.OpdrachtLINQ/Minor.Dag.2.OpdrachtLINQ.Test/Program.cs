﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Minor.Dag._2.OpdrachtLINQ.Test
{
    public class Program
    {
        
    }
}
