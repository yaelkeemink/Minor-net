﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public enum Muntsoort
    {
        Euro = 0,
        Gulden = 1,
        Florijn = 2,
        Dukaat = 3,
    }
}
